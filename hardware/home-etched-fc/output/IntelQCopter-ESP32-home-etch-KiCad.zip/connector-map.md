# Connector pin map

Component-side view. J4/J5/J6 match photographed signal order; all start VCC,GND,SCL,SDA. Module bodies mount offboard on wires. J2 is the DevKit right header (Espressif calls it J3).

| Reference | Function | Pin: net |
|---|---|---|
| J1 | DevKitC-1 LEFT 1x22 | 1: 3V3; 2: 3V3; 3: NC; 4: GPIO4; 5: GPIO5; 6: GPIO6; 7: GPIO7; 8: NC; 9: NC; 10: GPIO17; 11: GPIO18; 12: GPIO8; 13: NC; 14: NC; 15: GPIO9; 16: NC; 17: NC; 18: GPIO12; 19: NC; 20: GPIO14; 21: 5V_MCU; 22: GND |
| J2 | DevKitC-1 RIGHT 1x22 | 1: GND; 2: NC; 3: NC; 4: GPIO1; 5: GPIO2; 6: NC; 7: NC; 8: NC; 9: NC; 10: NC; 11: NC; 12: NC; 13: NC; 14: NC; 15: NC; 16: NC; 17: NC; 18: NC; 19: NC; 20: NC; 21: GND; 22: GND |
| J3 | REGULATED 5V ONLY | 1: GND; 2: 5V_EXT |
| J4 | GY-521 MPU6050 | 1: SENS_3V3; 2: GND; 3: I2C_SCL; 4: I2C_SDA; 5: NC; 6: NC; 7: GND; 8: NC |
| J5 | GY-BM280 I2C | 1: SENS_3V3; 2: GND; 3: I2C_SCL; 4: I2C_SDA; 5: BARO_CSB; 6: GND |
| J6 | GY-271 MAG | 1: SENS_3V3; 2: GND; 3: I2C_SCL; 4: I2C_SDA; 5: NC |
| J7 | SENSE ONLY | 1: VBAT_SENSE; 2: GND |
| J8 | ESC_FL | 1: ESC_FL; 2: GND |
| J9 | ESC_FR | 1: ESC_FR; 2: GND |
| J10 | ESC_RR | 1: ESC_RR; 2: GND |
| J11 | ESC_RL | 1: ESC_RL; 2: GND |
| J12 | OPTIONAL 3V3 UART | 1: COMP_TX; 2: COMP_RX; 3: GND |
| J13 | F2 MINI WIRE PADS | 1: GND; 2: LIDAR_5V; 3: LIDAR_RX_FC; 4: LIDAR_TX_FC |
| J14 | 0-2.5V current input | 1: GND; 2: SENS_3V3; 3: CURRENT_IN |
