# IntelQCopter AI-to-AI handoff bundle

**This package is for continuing development locally, not for flashing as a single firmware.**

1. Open `PROJECT_HANDOFF.md` for the complete technical history, hardware map, current known failures, configuration and commands.
2. If using a coding AI (Codex, local LLM agent, Cursor, etc.), add `AGENTS.md` to its project working directory and ask it to read `PROJECT_HANDOFF.md` and `NEXT_ACTIONS.md` first.
3. See `NEXT_ACTIONS.md` for the short, evidence-driven next test.
4. Historical source archives are in `reference_packages`. **Extract each into a separate directory.** Do not flash more than one project at once or mix their sources.
5. `reference_docs` includes longer prior research and model sources. The provided mass/inertia are only estimates; they are not flight measurements.

Snapshot: 2026-11-03. This is an evidence and code handoff; no flight-ready firmware is included or certified.
