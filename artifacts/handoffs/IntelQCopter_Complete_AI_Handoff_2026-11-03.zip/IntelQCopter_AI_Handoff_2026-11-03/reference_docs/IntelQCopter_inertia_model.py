#!/usr/bin/env python3
"""IntelQCopter F450: nominal component inertias, full-CG inertia tensors,
and reproducible Monte Carlo 1-sigma input-uncertainty propagation.

Frame: origin at middle of lower F450 PCB; +X forward between red front arms,
+Y left; +Z up (right-handed). All input lengths SI metres, masses kg.
This is a PROVISIONAL parameter model, not measured mass properties.

Run: python IntelQCopter_inertia_model.py --samples 60000 --out /path/to/folder
Dependencies: numpy (and standard library).
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict
import argparse, json, csv
import numpy as np

RADIUS = 0.225
DIAG = RADIUS / np.sqrt(2.)

@dataclass(frozen=True)
class Part:
    name: str
    group: str
    mass: float
    mass_sigma: float
    pos: tuple[float,float,float]
    pos_sigma: tuple[float,float,float]
    dims: tuple[float,float,float]
    kind: str = 'box'
    yaw: float = 0.0
    # For prop shape, dims[0] is 8-inch prop tip-to-tip length.


def part(name, group, mass, sigma, pos, psig, dims, kind='box', yaw=0):
    return Part(name, group, mass, sigma, tuple(pos), tuple(psig), tuple(dims),kind,yaw)


def components(include_pc: bool) -> list[Part]:
    c=[]
    # Bare frame 282g includes 4 arms, both plates and standard frame bolts.
    for k,(sx,sy) in enumerate(((+1,+1),(+1,-1),(-1,+1),(-1,-1)),1):
        a=np.arctan2(sy,sx)
        c += [part(f'Frame arm {k}', 'F450 frame', .048, .0025,
          (sx*.140/np.sqrt(2),sy*.140/np.sqrt(2),.011),
          (.003,.003,.004),(.170,.018,.016),'box',a)]
    c += [part('Lower frame plate','F450 frame',.056,.003,(0,0,0),(.002,.002,.001),(.180,.118,.002)),
          part('Upper frame plate','F450 frame',.019,.003,(0,0,.022),(.002,.002,.003),(.140,.118,.002))]
    for j,(sx,sy) in enumerate(((1,1),(1,-1),(-1,1),(-1,-1)),1):
        c += [part(f'Frame screws/nuts cluster {j}','F450 frame',.015/4,.001,
              (sx*.042,sy*.042,.010),(.002,.002,.004),(.012,.012,.012))]
    # Rotor radius exactly 225mm nominal; 8inch props are conditional build assumption.
    for j,(sx,sy) in enumerate(((1,1),(1,-1),(-1,1),(-1,-1)),1):
        a=np.arctan2(sy,sx)
        c += [part(f'A2212/10T motor {j}', '4 motors', .047, .006,
           (sx*DIAG,sy*DIAG,.038),(.002,.002,.005),(.028,.028,.028),'motor'),
          part(f'40A ESC {j}', '4 ESCs', .041, .009,
           (sx*DIAG/2,sy*DIAG/2,-.014),(.007,.007,.006),(.073,.028,.012),'box',a),
          part(f'8045 assumed prop {j}', '4 propellers', .009, .003,
           (sx*DIAG,sy*DIAG,.061),(.002,.002,.005),(.2032,.016,.003),'prop')]
    c += [part('3S 4200mAh LiPo','battery',.348,.038,
          (0,0,.0215),(.010,.008,.010),(.138,.046,.037)),
          part('100x75mm FC PCB+ESP32+modules','flight PCB and sensors',.048,.012,
          (0,0,.061),(.004,.004,.007),(.100,.075,.008)),
          part('TOFSense F2 Mini','LiDAR',.001,.00025,
          (0,0,-.041 if include_pc else -.008),(.002,.002,.003),(.019,.012,.0103))]
    # Four additional tall bolts with nuts, not the standard frame hardware.
    for j,(sx,sy) in enumerate(((1,1),(1,-1),(-1,1),(-1,-1)),1):
        c += [part(f'Extra long bolt/nut {j}','extra tall bolts',.003,.001,
          (sx*.035,sy*.028,.031),(.002,.002,.005),(.006,.006,.055))]
    # Other added wires / connectors, assumed distributed along the four arms.
    for j,(sx,sy) in enumerate(((1,1),(1,-1),(-1,1),(-1,-1)),1):
        a=np.arctan2(sy,sx)
        c += [part(f'Cable/connectors {j}','wiring and connectors',.025/4,.003,
         (sx*.106/np.sqrt(2),sy*.106/np.sqrt(2),.004),(.012,.012,.007),(.1,.009,.009),'box',a)]
    if include_pc:
        c += [part('N150 mini-PC bare working assembly','N150 mini-PC',.200,.065,
             (0,0,-.024),(.005,.005,.008),(.105,.105,.022)),
          part('N150 mounting isolation/power cable','N150 mount',.015,.007,
             (0,0,-.009),(.004,.004,.006),(.105,.090,.005))]
    assert abs(sum(x.mass for x in c)-(.1104E1 if not include_pc else 1.319)) < .001, sum(x.mass for x in c)
    return c


def intrinsic(part:Part, masses:np.ndarray) -> np.ndarray:
    """N x 3 x 3 intrinsic inertia, excluding COM translation."""
    n=len(masses)
    out=np.zeros((n,3,3))
    if part.kind=='motor':
        radius=part.dims[0]/2
        height=part.dims[2]
        d=np.array([(3*radius**2+height**2)/12, (3*radius**2+height**2)/12, radius**2/2])
    elif part.kind=='prop':
        # 78% distributed along two slender blades, 22% at a compact hub,
        # time-averaged over prop azimuth for x-y inertia; spin dynamics separate.
        D=part.dims[0]
        jz=.78*D*D/12+.22*(.010**2)/2
        d=np.array([jz/2,jz/2,jz])
    else:
        L,W,H=part.dims
        d=np.array([(W*W+H*H)/12,(L*L+H*H)/12,(L*L+W*W)/12])
    # Intrinsic I for a rotated cuboid (rotate x-axis by part.yaw about Z)
    co,si=np.cos(part.yaw),np.sin(part.yaw)
    out[:,0,0]=masses*(d[0]*co**2+d[1]*si**2)
    out[:,1,1]=masses*(d[0]*si**2+d[1]*co**2)
    out[:,0,1]=out[:,1,0]=masses*(d[0]-d[1])*co*si
    out[:,2,2]=masses*d[2]
    return out


def calc(parts:list[Part], n:int=1, rng=None, uncertain=False):
    rng = rng if rng is not None else np.random.default_rng(1)
    P=len(parts)
    mm=np.array([p.mass for p in parts])
    sig=np.array([p.mass_sigma for p in parts])
    rr=np.array([p.pos for p in parts])
    rsig=np.array([p.pos_sigma for p in parts])
    if uncertain:
        masses=np.maximum(.00001,mm[None,:]+rng.standard_normal((n,P))*sig[None,:])
        pos=rr[None,:,:]+rng.standard_normal((n,P,3))*rsig[None,:,:]
        # Shared +/-20g systematic frame-kit mass offset, preserving nominal split.
        offset=rng.standard_normal(n)*.020
        frame_indices=np.array([i for i,p in enumerate(parts) if p.group=='F450 frame'])
        fraction=mm[frame_indices]/sum(mm[frame_indices])
        masses[:,frame_indices]+=offset[:,None]*fraction[None,:]
        masses=np.maximum(.00001,masses)
        # Motor and prop centers stay paired physically; ESCs are separate.
        for j in range(4):
            mi=next(i for i,p in enumerate(parts) if p.name==f'A2212/10T motor {j+1}')
            pi=next(i for i,p in enumerate(parts) if p.name==f'8045 assumed prop {j+1}')
            pos[:,pi,:2]=pos[:,mi,:2]
        # Whole-frame symmetric origin offset correlated within components not sampled.
    else:
        masses=np.broadcast_to(mm,(n,P)).copy()
        pos=np.broadcast_to(rr,(n,P,3)).copy()
    M=masses.sum(axis=1)
    cg=np.einsum('nc,ncd->nd',masses,pos)/M[:,None]
    d=pos-cg[:,None,:]
    r2=np.einsum('nci,nci->nc',d,d)
    # Parallel-axis theorem in vectorized form:
    I=np.zeros((n,3,3))
    I += np.einsum('nc,nc,ij->nij',masses,r2,np.eye(3))
    I -= np.einsum('nc,nci,ncj->nij',masses,d,d)
    for j,p in enumerate(parts):
        I += intrinsic(p,masses[:,j])
    return M,cg,I,masses,pos


def group_rows(parts, cg):
    groups=defaultdict(lambda: {'mass':0.,'weighted_pos':np.zeros(3),'I':np.zeros((3,3))})
    for p in parts:
        g=groups[p.group]
        g['mass']+=p.mass
        g['weighted_pos']+=p.mass*np.array(p.pos)
        d=np.array(p.pos)-cg
        g['I']+=intrinsic(p,np.array([p.mass]))[0] + p.mass*(np.dot(d,d)*np.eye(3)-np.outer(d,d))
    rows=[]
    for k,v in groups.items():
        pos=v['weighted_pos']/v['mass']
        rows.append([k,round(v['mass']*1000,3),*(np.round(pos*1000,3)),*np.round(v['I'].ravel(),9)])
    return rows


def save_csv(path,header,rows):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(header);w.writerows(rows)


def run(out:Path, samples:int=60000, seed:int=20261103):
    out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    result={
      'metadata':{'title':'IntelQCopter F450 mass properties v1: assumption-driven model',
        'units':'kg, m, kg*m^2', 'body_axes':'+X forward +Y left +Z up',
        'origin':'geometric center of lower F450 power-distribution PCB',
        'sampling':'independent normal priors for component masses/placement, plus frame systematic; not measured data',
        'samples':samples, 'seed':seed,
        'WARNING':'Provisional. Verify battery mounting gap, motor axis, exact N150 mass, ESC and propellers, wiring, bolt geometry.'},
      'configurations':{}}
    csv_rows=[]
    for key,has_pc in [('A',False),('B',True)]:
        parts=components(has_pc)
        M0,CG0,J0,_,_=calc(parts)
        M,CG,J,_,_=calc(parts,samples,rng,True)
        j_std=np.std(J,axis=0,ddof=1)
        # For nominal symmetric layout offdiagonal can be zero aside from numerical noise.
        rr={
          'model': 'F450 plus N150 below plate' if has_pc else 'F450 basic sensor build',
          'total_mass_kg_nominal':float(M0[0]),
          'total_mass_kg_1sigma':float(M.std(ddof=1)),
          'total_mass_kg_MC_mean':float(M.mean()),
          'center_of_mass_m_nominal':CG0[0].tolist(),
          'center_of_mass_m_1sigma':CG.std(axis=0,ddof=1).tolist(),
          'inertia_about_COM_kgm2_nominal':J0[0].tolist(),
          'inertia_about_COM_kgm2_1sigma':j_std.tolist(),
          'inertia_about_COM_kgm2_MC_mean':J.mean(axis=0).tolist(),
          'ninetyfive_percentile_intervals':{
             'mass_kg': np.quantile(M,[.025,.975]).tolist(),
             'center_of_mass_m': np.quantile(CG,[.025,.975],axis=0).tolist(),
             'inertia_diag_kgm2':np.quantile(J[:,[0,1,2],[0,1,2]],[.025,.975],axis=0).tolist()},
          'components':[{'name':p.name,'group':p.group,'mass_kg':p.mass,
                          'mass_sigma_kg':p.mass_sigma,'xyz_m':p.pos,
                          'xyz_sigma_m':p.pos_sigma, 'dims_m':p.dims,'kind':p.kind} for p in parts]
        }
        result['configurations'][key]=rr
        h=['group','mass_g','cg_x_mm','cg_y_mm','cg_z_mm',*('I'+a+b+'_kgm2' for a in 'xyz' for b in 'xyz')]
        save_csv(out/f'config_{key}_inertia_by_component_group.csv',h,group_rows(parts,CG0[0]))
        for g in group_rows(parts,CG0[0]):
            csv_rows.append([key]+g)
        print(f'CONFIG {key} M={M0[0]:.6f} +/-{M.std(ddof=1):.6f} kg CG mm={CG0[0]*1000} sigma mm={CG.std(0,ddof=1)*1000}')
        print('J nominal kg m2:');print(J0[0]);print('J sigma kg m2:');print(j_std)
        print('J principal moments: ', np.linalg.eigvalsh(J0[0]))
    with open(out/'IntelQCopter_inertia_results.json','w',encoding='utf-8') as f:
        json.dump(result,f,indent=2)
    save_csv(out/'all_component_groups.csv',['config','group','mass_g','cg_x_mm','cg_y_mm','cg_z_mm',*('I'+a+b for a in 'xyz' for b in 'xyz')],csv_rows)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--samples',type=int,default=60000)
    parser.add_argument('--seed',type=int,default=20261103)
    parser.add_argument('--out',type=Path,default=Path(__file__).parent)
    opts=parser.parse_args()
    run(opts.out,opts.samples,opts.seed)
