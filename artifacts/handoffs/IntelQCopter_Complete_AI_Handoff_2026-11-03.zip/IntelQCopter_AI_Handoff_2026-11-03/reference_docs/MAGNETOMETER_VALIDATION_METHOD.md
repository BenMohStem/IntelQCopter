# IntelQCopter: scientific magnetometer calibration and error assessment

**Scope:** QMC5883P (I²C `0x2C`) with a permanent magnetic environment; the estimator is also compatible with HMC5883L and QMC5883L CSV records. Hardware is **not** proven safe to fly. This analysis addresses *magnetic magnitude* calibration and validity, **not** absolute yaw accuracy.

## 1. Measurement model and why a perfect pivot is not required

Let `m_k` be the magnetometer's three-axis output (µT), `b` the sensor/body-fixed additive hard-iron offset (µT), `A` a nonsingular 3×3 soft-iron/sensitivity matrix, `R_k` the body-to-world orientation matrix, `B(r_k)` the environmental magnetic field (µT) at sensor position `r_k`, and `epsilon_k` the measurement noise (µT). Then

```
m_k = A R_k^T B(r_k) + b + epsilon_k .
```

If `B(r)` is constant across the swept volume, translating the whole board has no effect on the ideal norm constraint `||A^-1(m-b)||=||B||`. **Keeping the sensor fixed at an exact center is therefore not required** for the ellipsoid fit. A sensor rotating around a hand-held pivot 10 cm away is fine *if the external field is homogeneous*.

When field gradients are appreciable,

```
B(r + delta_r) = B(r) + G_B delta_r + O(||delta_r||^2),
(G_B)_ij = partial B_i / partial r_j .
```

The 3×3 gradient `G_B` has units µT/m. Without independent measurements of `G_B` and `delta_r`, the product `G_B delta_r` cannot be separated from other errors by magnetic ellipsoid fitting alone. In an office, steel tables, loudspeakers, magnets, power supplies and current-carrying cables can make field homogeneity poor. This is why additional *independent sessions* are useful.

## 2. Calibration model

A positive-definite shape correction `S` and offset `b` are found by minimizing a robust radial residual:

```
r_k(b,S) = || S(m_k-b) ||_2 - 1;
J(b,S) = sum_k rho( r_k(b,S) / sigma ),   S = L L^T > 0 .
```

Here `rho` is a soft-L1 robust loss and `L` a triangular matrix with positive diagonal; the optimizer searches nine independent unknowns. The unit-sphere `S` has units 1/µT. The scaled 3×3 matrix `M=S*B_ref` is dimensionless when `B_ref` is estimated in µT.

**Identifiability limitations:** Unknown absolute field magnitude prevents absolute gain calibration; an unknown orthogonal factor between body and sensor axes cannot be identified from scalar norm alone. Therefore a low fitted norm residual does **not** prove 1° or any other heading accuracy. External attitude/heading truth or magnetometer/gyro joint calibration is needed to quantify that.

## 3. Metrics now calculated by `tools/magnetometer_quality.py`

1. **Chronological holdout:** first 80% of each motion stage is training; its last 20% is evaluated using the *frozen training fit*. Both radial RMS and 95th/99th absolute error are reported. Because nearby samples may remain correlated, this is **not** a completely independent validation.
2. **New-session validation:** when you select multiple independently recorded sessions, each session is held out while the model is fitted on the others. Numbered `*_partNN.csv` checkpoints from the same recording count as **one** session, correctly.
3. **Directional coverage:** a Fibonacci grid of 128 approximately uniform directions is checked for an observed calibrated magnetic direction within 18°. Also report occupied direction bins and normalized occupancy entropy. This catches repeated yaw-only circles and missing upside-down/diagonal poses.
4. **Block bootstrap:** resample contiguous groups of approximately 50 fresh magnetic measurements (about 1 s at 50 Hz), not independent individual readings, and refit. The spread of center and soft-iron matrix estimates reports *repeatability sensitivity* (exploratory percentile intervals; **not** calibrated error bars).
5. **Model condition number and robust residuals:** check whether correction anisotropy and residual distribution are plausible.

### Interpreting an error figure

If the held-out `rms_fraction=0.0131`, the corrected **magnetic-field magnitude** varies with approximately 1.31% RMS residual relative to the internal radius. **This is not a 1.31% heading error, nor a 1.31° heading error.** A systematic mounting axis rotation may give *zero radial error and still yield wrong yaw*.

### Current sample reference

In the 2026-11-02 hand-rotation recording, fresh QMC5883P points = 11,000; coverage within 18° = 87.5%; the training radial RMS was about 1.13%, and the chronological held-out radial RMS about 1.31%. One recording alone cannot establish cross-session stability. This data is **not** included in the downloadable ZIP; only the derived diagnostic report is.

## 4. Recommended experiments with USB cable and screws

**A. Baseline experiment:** Magnetometer securely attached in the **final mechanical configuration**, screws tightened, battery and motors disconnected for safety. Remove any loose steel tools, magnets and electric motors from the work surface. Use a nonferrous stand and avoid a steel desk. Make a fresh full 3D rotation recording.

**B. USB routing control:** Fix the USB cable with a gentle nonmagnetic strain relief so it does not swing across the magnetometer during the run. Route the cable away from the magnetic sensor, and keep it routed similarly for every measurement. Do not twist or pull the connector. If possible place PC and power adapter well away from the rotation region. Use a USB extension so the PC stays distant. **Do not disconnect the USB during a recording.**

**C. Repeatability experiment:** Save the first recording, then independently repeat the complete 3D rotation, including all diagonal and inverted directions. Analyze both, and compare the leave-one-session-out residuals and hard-iron centers.

**D. Cable intervention:** With motor outputs disconnected, make a second pair of recordings with a deliberately *different cable path*, e.g. far from versus near the magnetometer (but never touch electrical contacts). If the fitted offsets shift, the cable geometry/electrical return path contributes a magnetic bias. For flight, the tether disappears: a tethered calibration may not perfectly represent an untethered configuration. A battery-safe independent logger is the long-term solution once PCB power safety is verified.

**E. Mechanical components:** Steel screws *fixed to the drone* usually create body-fixed hard/soft-iron distortion. Calibrate with the final screws installed. Recalibrate after changing screws, moving wires or attaching magnets. Ferromagnetic screws can still distort the field substantially; replace with nonmagnetic fasteners when mechanically appropriate.

**F. Phase rotations:** YAW/PITCH/ROLL stages are helpful but do not assure 3D coverage. Spend the long `TUMBLE` stage placing the craft in many **distinct** orientations: +X/-X/+Y/-Y/+Z/-Z up, 45° and 135° diagonal attitudes, and inversions. Move smoothly and stop briefly in each orientation; avoid turning in a tight circle beside the PC. More repeated samples in one orientation cannot replace missing directions.

## 5. Commands

Run one or several **completed** captured files:

```powershell
py -3 tools\magnetometer_quality.py captures\run1.csv captures\run2.csv --output-prefix captures\study
```

The calculator creates `captures\study.json` and `captures\study.png`. In the GUI use **Assess MAG precision / coverage from CSVs...** and select the closed file(s); it operates while the stream continues.

## 6. Research grounding and limitations

- M. Kok and T. B. Schön, *Magnetometer calibration using inertial sensors*, IEEE Sensors Journal 16(14), 2016. https://arxiv.org/abs/1601.05257 — maximum-likelihood calibration and sensor-axis misalignment; requires more than scalar fitting.
- E. Rodríguez-Rojo, J. Cubas, S. Pindado, *On the UPMSat-2 magnetometer's calibration methods performance comparison for poorly conditioned datasets*, Measurement 207 (2023), doi:10.1016/j.measurement.2022.112381 — sparse, poorly conditioned orientation data.
- *Automatic Determination of Validity of Input Data Used in Ellipsoid Fitting MARG Calibration Algorithms*, Sensors (2013). https://pmc.ncbi.nlm.nih.gov/articles/PMC3821311/ — validating input orientation distribution.
- *Magnetic Field Sensors' Calibration: Algorithms' Overview and Comparison*, Sensors (2021). https://pmc.ncbi.nlm.nih.gov/articles/PMC8401862/ — calibration models and assumptions.
- *Online Magnetometer Calibration in Indoor*, https://openreview.net/pdf?id=Qwg40Q4MB_ — non-uniform indoor magnetic fields and local-field assumption.
- Xsens, *Magnetic Calibration Manual*, https://www.mouser.com/pdfDocs/MT_Magnetic_Calibration_Manual.pdf — body-fixed vs environmental disturbances.

The algorithm implemented here is a documented engineering adaptation, **not** a verbatim implementation of those papers, a certified calibration, or a measurement of aircraft heading accuracy. For final navigation performance, use an independent external heading/attitude reference and verify magnetometer-to-IMU proper rotation (determinant +1), including the X/Y axis-swap/sign issue noted previously.
