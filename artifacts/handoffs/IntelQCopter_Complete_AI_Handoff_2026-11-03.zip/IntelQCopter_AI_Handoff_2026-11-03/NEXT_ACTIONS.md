# NEXT_ACTIONS — first hour plan for a local AI

## Do not start by editing the flight controller

The main blocker is the QMC5883P returning no data after its mode-register write, even with Wi-Fi off. A reliable 100 Hz *isolated* capture exists in v13, but the later v17 diagnostic (all 7 actually run modes, including 50 Hz) recorded zero samples. Reconcile this before declaring MAG calibration complete.

## Step A — evidence-preserving v18 triage

Extract `reference_packages/IntelQCopter_QMC5883P_AutoDiagnostics_v18_NoPurchase_Triage.zip` into its own folder. Close all COM readers. Confirm the port in Windows Device Manager. Props off and ESC outputs/power isolated. Use PowerShell:

```powershell
.\tools\run_auto_tests.ps1 -Port COM3 -Suite triage -PowerMode warm
```

No YKUSH purchase. `warm` is not a hardware power cycle. Do not run `full` until triage is interpreted. Confirm T0 suspend communication; F1 STOP+START vs A0 repeated-START after sensor start; G5 guarded QMC software reset; A1 100 Hz. Get `results/SESSION_*_SEND_THIS.zip` and summarize actual sample count and `POST_START_BUS` signals. If a COM-port busy error occurs, close all serial clients and follow the existing bounded retry behavior, preserving logs.

## Step B — patch exactly one known issue

Only if evidence says QMC STOP+START works when repeated START fails, port the minimally changed I²C helper into a **copy** of complete calibration v3 (not the v18 diagnostic binary). If all I²C fails after start, isolate power, bypass and sensor reset behavior first. Do not change MAG ODR, Wi-Fi, BMP rate, UART and I²C frequency simultaneously.

## Step C — UART full-sensor preflight, no GUI

Extract `reference_packages/IntelQCopter_100Hz_UART_MAG_REPAIR_v3.zip` into another folder; after a code patch and source review:

```powershell
.\START_USB_CALIBRATION.ps1 -UploadFirmware -Check -Seconds 20
```

Validate CRC, MPU flags, MAG fresh flags, XYZ variation, BMP flags, frame loss and acquisition timestamps. 921600 baud, Wi-Fi off. **Only if it works**, run GUI without flashing:

```powershell
.\START_USB_CALIBRATION.ps1
```

LiDAR may be skipped from GUI. Don't claim success with `mag_fresh=0`.

## Step D — prepare 500 Hz, actuator-free FC bench

Only after sensor stabilization, run separate `IntelQCopter_FC_500Hz_Bench_v1.zip`. Start at I²C 100k, capture achieved `hz`, `imu_fail`, `missed`, `work_max_us`; evaluate whether a 400k experiment is justified. Attitude preview does not import the GUI matrices and yaw drifts; don't use for flight.

## Step E — report every run back to both AIs

Share exact command, ZIP/project commit, tested serial port, reset/power method, test duration, key `REGS` and `HEALTH` lines, raw logs and whether hardware actually produced valid samples. Assign sole ownership of flashing/COM reading to one process.
